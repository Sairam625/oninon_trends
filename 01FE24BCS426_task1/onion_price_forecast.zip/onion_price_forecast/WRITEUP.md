# Onion Price Forecasting: Hubli (Amaragol) APMC

**Data:** CEDA Agmarknet, Onion (Puna variety), Hubli (Amaragol) market, Dharwad. 2 Jan 2023 to 30 Oct 2025, 681 trading days. The portal limits each export to 1 year, so the data came as three yearly price files and three yearly arrivals files, merged in code.
**Model:** a LightGBM regressor (one model for all 1–14-day horizons) predicting the log change in modal price.

## 1. What was unusual in the raw data, and how it was handled

| Finding | Handling (and the rejected alternative) |
|---|---|
| **Several varieties on the same day** (Puna, Local, Telagi, Other): up to 4 rows per date, which looks like duplicates but isn't. Telagi almost disappears in 2025. | Modelled **Puna only**: present on 681 of 693 trading days and consistent for all 3 years. *Rejected:* averaging varieties, because the mix changes day to day and creates fake jumps. |
| **Date gaps.** Sundays and holidays are routine, plus long holes: all of Dec 2023 (32 days), Mar 2025 (26), Aug–Sep 2025 (16), and two 11–13 day gaps in Dec 2024. | Put the data on a daily calendar with a **causal forward-fill** and flags (`days_since_obs`). Days inside gaps > 7 days are never used as forecast origins, and only real observed prices are scored. *Rejected:* linear interpolation, because it uses the price *after* the gap, which leaks the future. |
| **Arrivals unit break on 18 Sep 2025.** Values drop about 10× overnight (≈270 → 27.79) and start carrying decimals. | Treated as a tonnes-vs-quintals change and scaled by **×10**. The corrected Sep–Oct 2025 median (≈566) matches Oct 2023 (≈584). Arrivals are also missing for Jun–Jul 2024 → forward-filled, with a `qty_missing` flag. |
| **Spikes.** Telagi p_max of ₹13,020 with modal ₹650 is an entry error, but it's outside the Puna series. In Puna, the Aug–Nov 2024 surge to ₹5,000 is **real** (national onion shortage). | **Kept the spikes, limited their influence:** log prices, rolling medians, and an L1 loss. *Rejected:* a Hampel/rolling-median clip, which would flatten the real 2024 surge (the very thing a forecaster must learn) and needs a centred, future-looking window. |
| **Flat stretches** of up to 7 identical prices. | Left as is: prices are quoted in round ₹50/₹100 steps, so these are normal, not stale data. |

## 2. Features and why

- **Past prices:** log-price lags (0, 1, 2, 3, 7, 14, 28 days), rolling mean/median/std over 7, 14 and 28 days, 28-day max/min, 7- and 28-day momentum, and distance from the 28-day median. Prices are highly persistent, so recent level and momentum carry most of the signal.
- **Arrivals (supply):** log arrivals, 7- vs 28-day trend.
- **Min–max spread:** a proxy for volatility and quality mix.
- **Seasonality of the target date:** day-of-year sin/cos and weekday. Known in advance, so legitimate. Onion follows a harvest cycle.
- **Horizon** `h` and **days since last observation.**

**Leakage check (automated in the notebook):** each feature was recomputed with all data after the origin deleted. The result was identical for 25 random origins (max difference 0.0). The target is the change from origin t to t+h, so every input is known at time t.

## 3. Validation: time-ordered vs random split (same model, same rows)

| Evaluation | MAE (₹/quintal) | MAPE |
|---|---|---|
| **Walk-forward** (5 expanding folds, Oct 2024 → Oct 2025) | **263** | **17.4%** |
| **Random 80/20 split** | **114** | **7.0%** |
| Baseline: last observed price (walk-forward) | 289 | 18.4% |

**The gap is 2.3×.** In a random split, each test row has training rows from the day before and the day after, with almost identical features and overlapping target days. The model is interpolating, not forecasting, and it also trains on 2025 to "predict" 2023. A direct test confirmed this: removing the day-of-year features barely moves the walk-forward error (263 → 265) but pushes the random-split error up from 114 to 140. Under random splitting, day-of-year acts as a lookup key for "copy the neighbouring day's answer". **The walk-forward figure is the honest one.**

**Honest reading of the walk-forward result:** the model beats the last-price baseline by about 9% overall, mostly in volatile periods (Oct 2024–Jan 2025: ₹481 vs ₹587). In the calm Aug–Oct 2025 fold it is *worse* than naive (₹197 vs ₹157). It learned an Oct–Nov price rise from 2023 and 2024 (both surge years) that didn't happen in 2025. The same thing shows in the last-14-day back-test (plot, right panel). The 14-day forecast (31 Oct – 13 Nov 2025) is ₹806–852, a mild rebound from the late-October drop to ₹700.

## 4. What I'd do differently with more time

**Add more history and outside signals before making the model fancier.** Two seasons aren't enough to learn seasonality without memorising those specific years. I'd pull 2015–2022 data, add the national benchmark price (Lasalgaon) and export-policy events as features, and produce quantile forecasts (P10/P50/P90) instead of a single number, since a trader cares more about the range than the exact value.
